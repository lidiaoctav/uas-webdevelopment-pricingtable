const checkbox = document.getElementById("checkbox");
const catman = document.getElementById("catman");
const champ = document.getElementById("champ");
const pirate = document.getElementById("pirate");

checkbox.addEventListener("click", () => {
  pirate.textContent = pirate.textContent === "$199.99" ? "$19.99" : "$199.99";
  catman.textContent =
    catman.textContent === "$249.99" ? "$24.99 " : "$249.99";
  champ.textContent = champ.textContent === "$399.99" ? "$39.99" : "$399.99";
});
